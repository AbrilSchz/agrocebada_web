# PLANTILLA (no son las celdas originales: el zip no incluye la libreta).
# Supone: X (DataFrame de features, índice = ID_POLIGONO), y (observado, NaN en parcelas sin dato),
# `modelo_base` = HistGradientBoostingRegressor(...) con los hiperparámetros finales.
import numpy as np, pandas as pd, shap
from sklearn.base import clone
from sklearn.model_selection import KFold   # o GroupKFold si hay productor/municipio/zona

lab = y.notna()
X_l, y_l = X[lab], y[lab]

# 1) Predicción OOF (parcelas con observado) con fold_id
oof = pd.Series(np.nan, index=X.index); fold = pd.Series(np.nan, index=X.index)
cv = KFold(n_splits=5, shuffle=True, random_state=42)       # fijar y documentar
for k, (tr, va) in enumerate(cv.split(X_l), start=1):
    m = clone(modelo_base).fit(X_l.iloc[tr], y_l.iloc[tr])
    oof.iloc[X.index.get_indexer(X_l.index[va])] = m.predict(X_l.iloc[va])
    fold.iloc[X.index.get_indexer(X_l.index[va])] = k

# 2) Modelo final (todas las parcelas con observado) -> predicción en TODAS y SHAP
final = clone(modelo_base).fit(X_l, y_l)
pred_final = pd.Series(final.predict(X), index=X.index)
expl = shap.TreeExplainer(final)
sv = expl(X)
base = float(np.ravel(sv.base_values)[0])
aportes = pd.DataFrame(sv.values, index=X.index, columns=X.columns)
pred_explicada = base + aportes.sum(axis=1)
assert np.allclose(pred_explicada, pred_final, atol=1e-6), "SHAP no reconstruye el modelo final"

# 3) resultados.csv
res = pd.DataFrame({
    "ID_POLIGONO": X.index,
    "observado": y.values,
    "prediccion": np.where(lab, oof, pred_final),          # OOF si hay observado; final si no
    "tipo_prediccion": np.where(lab, "oof_cv", "modelo_final"),
    "fold_id": fold.values,                                # NaN para modelo_final
    "prediccion_modelo_final": pred_final.values,
    "prediccion_explicada": pred_explicada.values,         # = base + sum(aportes)
    "valor_base_t_ha": base,                               # base del modelo final (la que explica SHAP)
    "modelo_explicado": "modelo_final_todas_las_parcelas_con_observado",
    "unidad_rendimiento": "t/ha",
    # "productor_id", "municipio", "zona": agregar si existen en la fuente original
})
res.to_csv("resultados.csv", index=False)
aportes.stack().rename("aporte_t_ha").reset_index(names=["ID_POLIGONO", "variable"]).to_csv(
    "contribuciones_largo.csv", index=False)               # añadir valor y unidad por variable

# 4) Métrica honesta: solo OOF vs observado
r = res[lab.values]
print("RMSE OOF:", np.sqrt(((r.prediccion - r.observado) ** 2).mean()))
